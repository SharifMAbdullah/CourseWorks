package Introduction;

public class Main {
    public static void main(String[] args) {


        Bank NewAccount= new Bank();
            NewAccount.startBanking();

    }
}
