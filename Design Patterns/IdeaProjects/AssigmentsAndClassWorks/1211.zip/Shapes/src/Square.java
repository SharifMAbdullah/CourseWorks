public class Square extends Shape{
    Square(int x){
        super(x,x);
    }
}
